
let carrinho = [];

function mostrar(aba) {
  document.getElementById('loja').classList.remove('visivel');
  document.getElementById('carrinho').classList.remove('visivel');
  document.getElementById(aba).classList.add('visivel');
  if (aba === 'carrinho') atualizarCarrinho();
}

function adicionarAoCarrinho(nome, preco) {
  carrinho.push({ nome, preco });
  alert(nome + ' adicionado ao carrinho!');
}

function atualizarCarrinho() {
  const lista = document.getElementById('listaCarrinho');
  lista.innerHTML = '';
  let total = 0;
  carrinho.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item.nome + ' - R$' + item.preco.toFixed(2);
    lista.appendChild(li);
    total += item.preco;
  });
  document.getElementById('total').textContent = total.toFixed(2);
}

function gerarPix() {
  const codigo = 'PIX-' + Math.floor(Math.random() * 1000000);
  const div = document.getElementById('codigoPix');
  div.innerHTML = '<strong>Código Pix:</strong> ' + codigo + '<br><small>Válido por 5 minutos.</small>';
  setTimeout(() => {
    div.innerHTML = '<span style="color:red">Código expirado. Gere um novo código.</span>';
  }, 300000);
}
